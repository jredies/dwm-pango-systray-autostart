dwm-pango-systray-autostart
=====

This a patch version of `dwm6.0` (http://dwm.suckless.org/) patched with 
`pango`, `systray` and `autostart`. The colorscheme is `zenburn` and there some
adjustments to the `config.h`.
